#========================== CalculatePat.xps.R ================================
#-----------------  Copyright (C) 2016 John Feng  -----------------------------
#
#   This file is a part of the package xps. It calculate Patterson function.
#
#   The xps package is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 2 of the License, or
#   any later version.
#
#   The xps package is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty
#   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#------------------------------------------------------------------------------
calculatePat.xps <- function(x){
  gc()
  if(!is.xps(x))
    stop("Not an xps object")
  #rearrange SF to call FFTW
  xc <- x$Cgrid
  numP <- xc$numP
  dimX <- xc$dimX
  dimY <- xc$dimY
  dimZ <- xc$dimZ
  real <- rep(0.0, numP)
  setRS(real, x$Smatrix$SF, x$Smatrix$wdw)
  imag = rep(0,numP)
  temp <- array(complex(real=real, imaginary = imag), dim=c(dimX, dimY, dimZ))
  tmp <- Re(fftw3d(temp, 0))
  return(tmp/x$Crystal$cV)
}

#--------------------------------------------------------------------------------------
# Read x-ray diffraction data and setup the solution framework
#--------------------------------------------------------------------------------------
load.xps <- function(fileName, gridRatio=1.0){
  if(!file.exists(fileName))
    stop("File '", fileName, "' is not found. ")
  gc()

  #1. get the title
  title <- NULL
  ctype <- 0
  if(n <- contains(fileName, "-sf.cif")){
    ctype <- 1
    title <- substr(fileName, 1, n-1)
  }
  else if(n <- contains(fileName, ".hkl")){
    ctype <- 2
    title <- substr(fileName, 1, n-1)
  }
  else{
    stop("Data file is not supported. ")
  }

  #2. get cell info
  crystal = NULL
  lines <- readLines(fileName)       # a string list
  numRefls <- length(lines)          # last line contains "End of .."
  if(numRefls<10)
    stop("No data in the file")
  for(i in 1:5){ #remove empty lines
    tmp1 = as.character(lines[numRefls])
    if(tmp1=="" | tmp1==" "){
      numRefls = numRefls-1
    }
  }
  if(contains(lines[numRefls], "END"))
    numRefls = numRefls-1
  #_cell.length_a      40.824
  #can use grep, str_count or regexpr(pattern ="_cell", lines[1:120])
  tmp4 <- 1
  Gamma <- 0.0
  i <- 2
  while(i<120 & Gamma < 2.0){
    tmp1 <- lines[i]
    len <- nchar(tmp1)
    if(contains(tmp1,"_cell")>0){
      if(n<-contains(tmp1, "length_a"))
        cA <- as.numeric(substr(tmp1, n+9, len))
      else if(n<-contains(tmp1, "length_b"))
        cB <- as.numeric(substr(tmp1, n+9, len))
      else if(n<-contains(tmp1, "length_c"))
        cC <- as.numeric(substr(tmp1, n+9, len))
      else if(n<-contains(tmp1, "angle_alpha"))
        Alpha <- as.numeric(substr(tmp1, n+12, len))
      else if(n<-contains(tmp1, "angle_beta"))
        Beta <- as.numeric(substr(tmp1, n+11, len))
      else if(n<-contains(tmp1, "angle_gamma")){
        Gamma <- as.numeric(substr(tmp1, n+12, len))
        tmp4 <- i
      }
    }
    i <- i+1
  }
  if(Gamma<2.0)
    stop("cell data not in the right format")
  tmp1 <- pi/180.0
  Alpha <- Alpha * tmp1
  Beta <- Beta * tmp1
  Gamma <- Gamma * tmp1

  #get symmetry info
  if(ctype==1){
    #_symmetry.space_group_name_H-M   'P 1 21 1'
    tmp1 <- grep("_symmetry.space_group_", lines[1:120])    #return the index of the line
    if(is.null(tmp1))
      stop("No standard symmetry info found...")
    tmp2 <- unlist(strsplit(lines[tmp1], "'"))
    sgName <- tmp2[2]
    tmp <- getSymMatrix(sgName)
    if(is.null(tmp))
      stop("Please extend the function getSymMatrix to include the symmetry")
    numOP <- tmp$numOP
    op    <- tmp$op
  }
  else{
    #_symmetry_equiv_pos_as_xyz
    tmp1 <- grep("x, y, z", lines[1:150])
    if(length(tmp1)<1)
      stop("No standard symmetry info found")
    op <- matrix(rep(0,192*12), nrow = 192, ncol=12)
    nop <- 1
    op[nop, 1] <- 1;     op[nop, 5] <- 1;     op[nop, 8] <- 1
    #'x, y, z'
    #'-x, -y, z+1/2'
    #'-x+1/2, y+1/2, z+1/2'
    #'x+1/2, -y+1/2, z'
    i <- tmp1[1]+1
    done <- FALSE
    while(!done & i<300){
      tmp1 <- lines[i]
      if(tmp1!="" & contains(tmp1,"x") & contains(tmp1,"y") & contains(tmp1,"z")){
        tmp2 <- unlist(strsplit(tmp1, ","))
        if(length(tmp2)==3){
          nop = nop+1
          tmp3 <- tmp2[1]
          if(contains(tmp3,"-x")>0)
            op[nop,1] <- -1
          else if(contains(tmp3,"x")>0)
            op[nop,1] <- 1
          if(contains(tmp3,"-y")>0)
            op[nop,2] <- -1
          else if(contains(tmp3,"y")>0)
            op[nop,2] <- 1
          if(contains(tmp3,"-z")>0)
            op[nop,3] <- -1
          else if(contains(tmp3,"z")>0)
            op[nop,3] <- 1
          if(contains(tmp3,"1/2")>0)
            op[nop,10] <- 6
          if(contains(tmp3,"-1/4")>0)
            op[nop,10] <- -3
          else if(contains(tmp3,"1/4")>0)
            op[nop,10] <- 3
          if(contains(tmp3,"-3/4")>0)
            op[nop,10] <- 3
          else if(contains(tmp3,"3/4")>0)
            op[nop,10] <- -3
          if(contains(tmp3,"-1/3")>0)
            op[nop,10] <- -4
          else if(contains(tmp3,"1/3")>0)
            op[nop,10] <- 4
          if(contains(tmp3,"-2/3")>0)
            op[nop,10] <- 4
          else if(contains(tmp3,"2/3")>0)
            op[nop,10] <- -4
          if(contains(tmp3,"-1/6")>0)
            op[nop,10] <- -2
          else if(contains(tmp3,"1/6")>0)
            op[nop,10] <- 2
          if(contains(tmp3,"-5/6")>0)
            op[nop,10] <- 2
          else if(contains(tmp3,"5/6")>0)
            op[nop,10] <- -2
          #------------------------------------------------
          tmp3 <- tmp2[2]
          if(contains(tmp3,"-x")>0)
            op[nop,4] <- -1
          else if(contains(tmp3,"x")>0)
            op[nop,4] <- 1
          if(contains(tmp3,"-y")>0)
            op[nop,5] <- -1
          else if(contains(tmp3,"y")>0)
            op[nop,5] <- 1
          if(contains(tmp3,"-z")>0)
            op[nop,6] <- -1
          else if(contains(tmp3,"z")>0)
            op[nop,6] <- 1
          if(contains(tmp3,"1/2")>0)
            op[nop,11] <- 6
          if(contains(tmp3,"-1/4")>0)
            op[nop,11] <- -3
          else if(contains(tmp3,"1/4")>0)
            op[nop,11] <- 3
          if(contains(tmp3,"-3/4")>0)
            op[nop,11] <- 3
          else if(contains(tmp3,"3/4")>0)
            op[nop,11] <- -3
          if(contains(tmp3,"-1/3")>0)
            op[nop,11] <- -4
          else if(contains(tmp3,"1/3")>0)
            op[nop,11] <- 4
          if(contains(tmp3,"-2/3")>0)
            op[nop,11] <- 4
          else if(contains(tmp3,"2/3")>0)
            op[nop,11] <- -4
          if(contains(tmp3,"-1/6")>0)
            op[nop,11] <- -2
          else if(contains(tmp3,"1/6")>0)
            op[nop,11] <- 2
          if(contains(tmp3,"-5/6")>0)
            op[nop,11] <- 2
          else if(contains(tmp3,"5/6")>0)
            op[nop,11] <- -2
          #------------------------------------------------
          tmp3 <- tmp2[3]
          if(contains(tmp3,"-x")>0)
            op[nop,7] <- -1
          else if(contains(tmp3,"x")>0)
            op[nop,7] <- 1
          if(contains(tmp3,"-y")>0)
            op[nop,8] <- -1
          else if(contains(tmp3,"y")>0)
            op[nop,8] <- 1
          if(contains(tmp3,"-z")>0)
            op[nop,9] <- -1
          else if(contains(tmp3,"z")>0)
            op[nop,9] <- 1
          if(contains(tmp3,"1/2")>0)
            op[nop,12] <- 6
          if(contains(tmp3,"-1/4")>0)
            op[nop,12] <- -3
          else if(contains(tmp3,"1/4")>0)
            op[nop,12] <- 3
          if(contains(tmp3,"-3/4")>0)
            op[nop,12] <- 3
          else if(contains(tmp3,"3/4")>0)
            op[nop,12] <- -3
          if(contains(tmp3,"-1/3")>0)
            op[nop,12] <- -4
          else if(contains(tmp3,"1/3")>0)
            op[nop,12] <- 4
          if(contains(tmp3,"-2/3")>0)
            op[nop,12] <- 4
          else if(contains(tmp3,"2/3")>0)
            op[nop,12] <- -4
          if(contains(tmp3,"-1/6")>0)
            op[nop,12] <- -2
          else if(contains(tmp3,"1/6")>0)
            op[nop,12] <- 2
          if(contains(tmp3,"-5/6")>0)
            op[nop,12] <- 2
          else if(contains(tmp3,"5/6")>0)
            op[nop,12] <- -2
        }
        else
          done <- TRUE
      }
      else
        done <- TRUE
      i <- i+1
    }
    numOP <- nop
  }
  tmp   <- 2.0 * cos(Alpha) * cos(Beta) * cos(Gamma)
  cV    <- cA * cB *cC*sqrt(1.0-cos(Alpha)*cos(Alpha)-cos(Beta)*cos(Beta)-cos(Gamma)*cos(Gamma)-tmp)
  #reciprocal parameters
  cA1   <- cB * cC *sin(Alpha) /cV
  cB1   <- cA *cC * sin(Beta) /cV
  cC1   <- cA * cB *sin(Gamma) /cV
  Alpha1<- (cos(Beta)*cos(Gamma) - cos(Alpha)) / sin(Beta) / sin(Gamma);
  Beta1 <- (cos(Alpha)*cos(Gamma) - cos(Beta)) / sin(Alpha) / sin(Gamma);
  Gamma1 <- (cos(Alpha)*cos(Beta) - cos(Gamma)) / sin(Alpha) / sin(Beta);
  #calculate basic matrix
  gt1 = cA1 * cA1
  gt2 = cB1 * cB1
  gt3 = cC1 * cC1
  gt4 = 2.0 * cA1 * cB1 * Gamma1
  gt5 = 2.0 * cA1 * cC1 * Beta1
  gt6 = 2.0 * cB1 * cC1 * Alpha1
  Gt  = c(gt1, gt2, gt3, gt4, gt5, gt6)
  GG  = matrix(rep(0.0, 9), nrow=3, ncol=3, byrow=TRUE)   #reciprocal: (a*, b*, c*)T = GG (a, b, c)T
  RR  = matrix(rep(0.0, 9), nrow=3, ncol=3, byrow=TRUE)   #direct space
  GG[1, 1] = gt1;			    GG[1, 2] = cA1*cB1*Gamma1;	GG[1, 3] = cA1 * cC1 * Beta1;
  GG[2, 1] = GG[1, 2];		GG[2, 2] = gt2;				      GG[2, 3] = cB1 * cC1 * Alpha1;
  GG[3, 1] = GG[1, 3];		GG[3, 2] = GG[2, 3];			  GG[3, 3] = gt3;
  RR[1, 1] = cA*cA;	    RR[1, 2] = cA*cB*cos(Gamma);	RR[1, 3] = cA*cC*cos(Beta);
  RR[2, 1] = RR[1, 2];	RR[2, 2] = cB*cB;			        RR[2, 3] = cB*cC*cos(Alpha);
  RR[3, 1] = RR[1, 3];	RR[3, 2] = RR[2, 3];			    RR[3, 3] = cC*cC;
  Mx = matrix(rep(0.0, 9), nrow=3, ncol=3, byrow=TRUE)
  MI = matrix(rep(0.0, 9), nrow=3, ncol=3, byrow=TRUE)
  tmp = (cos(Alpha) - cos(Beta)*cos(Gamma)) / sin(Gamma);
  tmp1 = cos(Beta)*sin(Gamma);
  Mx[1, 1] = cA;		Mx[1, 2] = cB*cos(Gamma);		Mx[1, 3] = cC*cos(Beta);
  Mx[2, 1] = 0.0;		Mx[2, 2] = cB*sin(Gamma);		Mx[2, 3] = cC*(cos(Alpha) - cos(Beta)*cos(Gamma))/sin(Gamma);
  Mx[3, 1] = 0.0;		Mx[3, 2] = 0.0;					    Mx[3, 3] = cV/(cA*cB*sin(Gamma));
  MI[1, 1] = 1.0 / cA;	MI[1, 2] = -cos(Gamma)/cA/sin(Gamma);		MI[1, 3] = cB*cC*(cos(Gamma)*tmp-tmp1)/cV;
  MI[2, 1] = 0.0;			  MI[2, 2] = 1.0/cB/sin(Gamma);			    MI[2, 3] = -cA*cC*tmp/cV;
  MI[3, 1] = 0.0;			  MI[3, 2] = 0.0;							          MI[3, 3] = 1.0 / Mx[3, 3];
  #create object crystal: all basic parameters
  crystal <- Crystal(cA, cB, cC, Alpha, Beta, Gamma, numOP, op, cV, cA1, cB1, cC1, Alpha1, Beta1, Gamma1, Gt, Mx, MI)

  #3. get hkl data
  #_refln.index_h  .cif
  # _refln_index_h  .hkl
  hkls = NULL
  tmp4 <- tmp4+1
  numItems <- 0
  colH <- 1
  colF <- 1
  isF <- TRUE
  hklStart <- 1
  if(ctype==1){                      # -sf.cif
    i <- tmp4
    while(i<150 & (i-hklStart)!=2){
      tmp1 <- lines[i]
      if(contains(tmp1, "_refln.")){
        numItems <- numItems + 1
        if(contains(tmp1, "index_h"))
          colH <- numItems
        else if(contains(tmp1, "F_meas_au"))
          colF <- numItems
        #_refln.F_squared_meas
        else if(contains(tmp1, "intensity_meas") | contains(tmp1, "F_squared_meas")){
          colF <- numItems
          isF <- FALSE
        }
        hklStart <- i
      }
      i <- i+1
    }
  }
  else{                              #.hkl
    i <- tmp4
    while(i<150 & (i-hklStart)!=2){
      tmp1 <- lines[i]
      if(contains(tmp1,"_refln")){
        numItems <- numItems + 1
        if(contains(tmp1,"index_h")){
          colH <- numItems
        }
        else if(contains(tmp1, "F_squared_meas")>0){
          colF <- numItems
          isF <- FALSE
        }
        hklStart <- i
      }
      i <- i+1
    }
  }
  hklStart = hklStart + 1
  #Read in all the reflections and rm lines
  # find the positions of h, k, l, f in a line: 1 1 1  -71    3   11  o    6.885  1.444
  # split and remove empty entries
  tmp1 <- lines[hklStart]
  paste0(tmp1, " ")
  tmp2 <- nchar(tmp1)-1
  j <- 0
  sH <- 1 #if colH=1
  for(i in 1:tmp2){
    if(substr(tmp1, i, i)!=" " & substr(tmp1, i+1, i+1)==" "){
      j <- j + 1
      if(j==colH-1)
        sH = i+1
      if(j==colH)
        eH = i
      else if(j==colH+1)
        eK = i
      else if(j==colH+2)
        eL = i
      if(j==colF-1)
        sF = i+1
      else if(j==colF)
        eF = i
    }
  }
  Hg <- as.integer(substr(lines[hklStart:numRefls], sH, eH))
  Kg <- as.integer(substr(lines[hklStart:numRefls], eH+1, eK))
  Lg <- as.integer(substr(lines[hklStart:numRefls], eK+1, eL))
  F2 <- as.numeric(substr(lines[hklStart:numRefls], sF, eF))     #vector
  if(isF)
    F2 <- sapply(F2, function(x) x*x)
  numG0 <- numRefls-hklStart + 1
  Glen <- sapply(1:numG0, function(i){Hg[i]*Hg[i]*gt1+Kg[i]*Kg[i]*gt2+Lg[i]*Lg[i]*gt3+Hg[i]*Kg[i]*gt4+Hg[i]*Lg[i]*gt5+Kg[i]*Lg[i]*gt6})
  remove(lines)
  hkls <- Hkls(numG0, Hg, Kg, Lg, F2, Glen)

  #4. Setup 3d grid for {hkl} and rho
  cgrid = NULL
  mabc = cA;
  if (mabc < cB)
    mabc = cB;
  if (mabc < cC)
    mabc = cC;
  hh = max(c(max(Hg),-min(Hg)))
  hk = max(c(max(Kg),-min(Kg)))
  hl = max(c(max(Lg),-min(Lg)))
  tmp = min(c(cA/hh, cB/hk))	#resolution
  tmp = min(c(tmp, cC / hl))
  if(is.na(tmp))
    stop("Check the data--remove empty or non-data lines at the ending of the file")
  dimX = 2 * as.integer(cA / tmp + 2);
  dimY = 2 * as.integer(cB / tmp + 2);
  dimZ = 2 * as.integer(cC / tmp + 2);
  Grr = (dimX / cA + dimY / cB + dimZ / cC) / 6.0;
  sX = 0; sY = 0; sZ = 0;
  for (j in 1: numOP){    #find rotation order N
    if (abs(op[j, 10])>0 & 12 %/% abs(op[j, 10])>sX)
      sX = 12 %/% abs(op[j, 10]);
    if (abs(op[j, 11])>0 & 12 %/% abs(op[j, 11])>sY)
      sY = 12 %/% abs(op[j, 11]);
    if (abs(op[j, 12])>0 & 12 %/% abs(op[j, 12])>sZ)
      sZ = 12 %/% abs(op[j, 12]);
  }
  if (sX >= 2){
    if (sX>2)
      dimX = sX*as.integer(dimX / sX) + sX
  }
  if (sY >= 2){
    if (sY>2)
      dimY = sY*as.integer(dimY / sY) + sY
  }
  if (sZ >= 2){
    if (sZ>2)
      dimZ = sZ*as.integer(dimZ / sZ) + sZ
  }
  cgrid <- Cgrid(dimX, dimY, dimZ, Grr)

  #5. Set solution matrix
  #find equivalent reflections and normalize all of them
  # Divide the reciprocal space into shells of approxiamtely equal volume (same anglular distribution) then cal their averages
  smatrix = NULL
  maxlen = max(Glen)*1.0001
  G2Max1 = maxlen;
  numP <- dimZ*dimY*dimX
  #--expand F2o by full symmetry	& find Bj pair for non-centrosymmetry
  SF = rep(0.0, numP)  #column major: dimX contingurous
  wdw = rep(FALSE, numP)
  Fg = rep(0.0, numP)
  #normalize F2
  #top is row -major
  normalizeF2(numG0, Hg, Kg, Lg, Glen, F2, numOP, op, Gt, dimX, dimY, dimZ, Fg, SF, wdw)
  smatrix <- Smatrix(Fg, SF, wdw)

  #6. construct the xps object
  xps <- xps(title, crystal, hkls, cgrid, smatrix)
  return (xps)
}

contains <- function(Str, str){
  #find if Str contains str: if found return the starting index, otherwise return 0
  #grep works on a vector of strings, not a single str
  Len <- nchar(Str)
  len <- nchar(str)-1
  i <- 1
  found <- FALSE
  while(!found & i<=Len-len){
    if(substr(Str,i, i+len)==str)
      found <- TRUE
    else
      i <- i+1
  }
  if(!found)i<-0
  return(i)
}

getSymMatrix <- function(sgName){
  if(sgName == "P 1 21 1" | sgName == "P21" | sgName=="P 21"){
    numOP = 2
    op <- matrix(rep(0, 12*numOP), nrow=numOP, ncol=12, byrow = TRUE)
    op[2,1]=-1;  op[2,5]=1;  op[2,9]=-1
    op[2,11]=6; #6/12
  }
  else if(sgName == "P 21 21 21" | sgName=="P212121"){
    numOP = 4
    op <- matrix(rep(0, 12*numOP), nrow=numOP, ncol=12, byrow = TRUE)
    op[2,1]=-1;  op[2,5]=-1;  op[2,9]=1
    op[2,10]=6;  op[2,12]= 6  #6/12
    op[3,1]=-1;  op[3,5]=1;   op[3,9]=-1
    op[3,11]=6;  op[3,12]=6   #6/12
    op[4,1]=1;   op[4,5]=-1;  op[4,9]=-1
    op[4,10]=6;  op[4,11]=6   #6/12
  }
  else{
    numOP = 1
    op <- matrix(rep(0, 12), nrow=numOP, ncol=12, byrow = TRUE)
  }
  op[1,1]=1;    op[1,5]=1;    op[1,9]=1
  rtn = list(numOP = numOP, op = op)
  return(rtn)
}

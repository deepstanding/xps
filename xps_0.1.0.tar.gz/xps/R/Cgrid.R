# Define class Cgrid and create an object
Cgrid <- function(...)
  UseMethod("Cgrid")

Cgrid.default <- function(dimX, dimY, dimZ, Grr){
  imgSize <- dimX*dimY
  numP <- dimZ*imgSize
  Cgrid <- list(dimX=dimX, dimY=dimY, dimZ=dimZ, numP=numP, imgSize=imgSize, Grr=Grr)
  class(Crystal) <- c("Cgrid","list")
  return(Cgrid)
}

is.Crystal <- function(x)
{
  rtn <- any(attr(x,which="class") == "Cgrid")
  return(rtn)
}
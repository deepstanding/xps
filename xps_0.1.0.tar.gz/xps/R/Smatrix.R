# define class Smatrix
Smatrix <- function(...)
  UseMethod("Smatrix")

Smatrix.default <- function(Fg, SF, wdw){
  if(length(Fg)!=length(wdw))
    stop("Matrix length not match")
  Smatrix <- list(Fg = Fg, SF = SF, wdw = wdw)
  class(Smatrix) <- c("Smatrix","list")
  return(Smatrix)
}

is.Smatrix <- function(x)
{
  rtn <- any(attr(x,which="class") == "Smatrix")
  return(rtn)
}

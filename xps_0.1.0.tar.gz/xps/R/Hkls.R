#define Hkls class and create a HKLs object
Hkls <- function(...)
  UseMethod("Hkls")

Hkls.default <- function(numG0, Hg, Kg, Lg, F2, Glen){
  if(numG0!=length(Hg))
    stop("data length not match")
  Hkls <- list(numG0=numG0, Hg=Hg, Kg=Kg, Lg=Lg, F2=F2, Glen=Glen)
  class(Hkls) <- c("Hkls","list")
  return(Hkls)
}

is.Hkls <- function(x)
{
  rtn <- any(attr(x,which="class") == "Hkls")
  return(rtn)
}
#============================ solve.xps.R =====================================
#-----------------  Copyright (C) 2016 John Feng  -----------------------------
#
#   This file is a part of the package xps. It solves the structure using
#   an iterative method (J. Feng, Acta Cryst A 2012)
#
#   The xps package is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 2 of the License, or
#   any later version.
#
#   The xps package is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty
#   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#------------------------------------------------------------------------------
solve.xps <- function(xs, maxIter, nPeaks){
  if(!is.xps(xs))
    stop("Not an xps object")
  numG0 <- xs$Hkls$numG0
  if(numG0<10)
    stop("No diffraction data")

  #0. Prepare
  numP <- xs$Cgrid$numP
  dimX <- xs$Cgrid$dimX
  dimY <- xs$Cgrid$dimY
  dimZ <- xs$Cgrid$dimZ
  cV   <- xs$Crystal$cV
  cA   <- xs$Crystal$cA
  cB   <- xs$Crystal$cB
  cC   <- xs$Crystal$cC
  Alpha<- xs$Crystal$Alpha
  Beta <- xs$Crystal$Beta
  Gamma<- xs$Crystal$Gamma
  rt   <- c(cA * cA,
          cB * cB,
          cC * cC,
          cA * cB * cos(Gamma),
          cA * cC * cos(Beta),
          cB * cC * cos(Alpha))
  #rg   <- c(1.0/dimX, 1.0/dimY, 1.0/dimZ)
  #sums  <- c(sumF=0.0, sumF2=0.0)
  sums  <- sumff(xs$Smatrix$SF, xs$Smatrix$wdw) #sumF, sumF2, c0
  pThreshold <- 0.35*sqrt(sums[2])/cV
  pars  <- c(xC=0.0, xR=0.0)
  rtn <- c(xP=0.0, xN=nPeaks)
  nMax <- nPeaks

  #1. Initialize: Patterson function
  real <- rep(0,numP)
  setRS(real, xs$Smatrix$SF, xs$Smatrix$wdw)
  imag <- rep(0,numP)
  temp <- array(complex(real=real, imaginary = imag), dim=c(dimX, dimY, dimZ))
  Rho  <- Re(fftw3d(temp, 0))/cV      #3D array [i,j,k]
  #save(Rho, file="Rho.RData")
  Rho0 <- rep(0.0, numP)
  peakPicking(10, 1, pThreshold, dimX, dimY, dimZ, rt, as.vector(Rho), Rho0)  # May start from one peak of Pr

  #2. Iterate
  done = FALSE
  iter=1
  t0 <- as.integer(Sys.time())
  while(!done & iter<maxIter){
    #2.1 FFT{Rho0} to get structure factors (defined as inverse FFT)
    imag <- rep(0,numP)
    temp <- array(complex(real=Rho0, imaginary = imag), dim=c(dimX, dimY, dimZ))
    temp <- fftw3d(temp, 1)/cV

    #2.2 Modify temp(Fg, phase), (2Eg2-Ec2)*exp(i*phase)
    real <- Re(temp)
    imag <- Im(temp)
    pars <- phaseExt(real, imag, xs$Smatrix$SF, xs$Smatrix$wdw, sums)

    #2.3 FFT-1{Fg} to get Rho
    temp <- array(complex(real=real, imaginary = imag), dim=c(dimX, dimY, dimZ))
    Rho  <- Re(fftw3d(temp, 0))/cV

    #2.4 Density modification
    Rho0 <- rep(0.0, numP)
    if(rtn[2]>1.2*nPeaks)
      pThreshold <- pThreshold * 1.1
    else if(rtn[2]<0.8*nPeaks)
      pThreshold <- pThreshold * 0.9
    rtn <- peakPicking(nPeaks, 0, pThreshold, dimX, dimY, dimZ, rt, as.vector(Rho), Rho0)

    #2.5 Check the status
    iter = iter + 1
    t1 <- as.integer(Sys.time())
    if(iter%%10 == 0){
      print(iter)
      print(sprintf("%3.2f %3.2f %3.2f %d", pars[1], pars[2], rtn[1], rtn[2]))
      #save(Rho, file="Rho.RData")
      image(z = Rho[,dimY/2+1,], col=gray(1:256/256))
    }
  }
  return(Rho)
}

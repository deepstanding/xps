# Define the class 'xps': the whole project
xps <- function(...)
  UseMethod("xps")

xps.default <- function(title, crystal, hkls, cgrid, smatrix)
{
  rtn <- list(Title=title, Crystal=crystal, Hkls=hkls, Cgrid=cgrid, Smatrix=smatrix)
  class(rtn) <- c("xps", "list")
  return(rtn)
}

is.xps <- function(x)
{
  rtn <- any(class(x)=="xps")
  return(rtn)
}

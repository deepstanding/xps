#=============================  xps.R  ========================================
#-----------------  Copyright (C) 2016 John Feng  -----------------------------
#
#   This file is a part of the package xps. It define the class 'xps' and
#   the whole project
#
#   The xps package is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 2 of the License, or
#   any later version.
#
#   The xps package is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty
#   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#------------------------------------------------------------------------------
xps <- function(...)
  UseMethod("xps")

xps.default <- function(title, crystal, hkls, cgrid, smatrix)
{
  rtn <- list(Title=title, Crystal=crystal, Hkls=hkls, Cgrid=cgrid, Smatrix=smatrix)
  class(rtn) <- c("xps", "list")
  return(rtn)
}

is.xps <- function(x)
{
  rtn <- any(class(x)=="xps")
  return(rtn)
}

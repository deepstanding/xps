#define class Crystal and create a Crystal object
Crystal <- function(...)
  UseMethod("Crystal")

Crystal.default <- function (cA, cB, cC, Alpha, Beta, Gamma, numOP, op, cV, cA1, cB1, cC1,
                             Alpha1, Beta1, Gamma1, Gt, Mx, MI)
{
  Crystal <- list(cA = cA, cB = cB, cC = cC, Alpha = Alpha, Beta = Beta, Gamma = Gamma,
                  numOP = numOP, op = op, cV = cV, cA1 = cA1, cB1 = cB1, cC1 = cC1,
                  Alpha1 = Alpha1, Beta1 = Beta1, Gamma1 = Gamma1, Gt = Gt, Mx = Mx, MI = MI)
  class(Crystal) <- c("Crystal","list")
  return(Crystal)
}

is.Crystal <- function(x)
{
  rtn <- any(attr(x,which="class") == "Crystal")
  return(rtn)
}

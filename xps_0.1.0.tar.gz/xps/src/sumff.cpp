#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
NumericVector sumff(NumericVector f2, LogicalVector wdw){
  int numg=0, n=f2.size();
  NumericVector res(3);
  res[0]=0; res[1]=0; res[2]=0;
  for(int i=0;i<n;i++){
    if(wdw[i]){
      numg++;
      res[0] += sqrt(f2[i]);
      res[1] += f2[i];
    }
  }
  res[2] = res[1]-res[0]*res[0]/numg;
  return res;
}


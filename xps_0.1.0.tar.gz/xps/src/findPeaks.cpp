#include <numeric>
#include <algorithm>
#include <Rcpp.h>

using namespace Rcpp;

struct Item {
  double item;
  int idx;
  bool operator<(Item const& o) const {
    return item < o.item;
  }
  bool operator>(Item const& o) const {
    return item > o.item;
  }
};

// [[Rcpp::export]]
int findPeaks(double pThreshold, int dima, int dimb, int dimc, NumericVector data, IntegerVector mList, NumericVector wList)
{   //4/12/2011 deal with aggragation
  int i, j, k, q, i1, j1, k1, i2, j2, k2, dima1 = dima - 1, dimb1 = dimb - 1, dimc1 = dimc - 1, nab = dima*dimb;
  int kab, k1ab, k2ab, jk, j1k, j2k, jk1,j1k1,j2k1,jk2,j1k2,j2k2, ijk;
  double tmp;
  q = 0;
  for (k = 0; k < dimc; k++){
    k1 = (k + 1) % dimc;
    k2 = (k + dimc1) % dimc;
    kab = k*nab;
    k1ab = k1*nab;
    k2ab = k2*nab;
    for (j = 0; j < dimb; j++){
      j1 = (j + 1) % dimb;
      j2 = (j + dimb1) % dimb;
      jk = j*dima + kab;
      j1k = j1*dima + kab;
      j2k = j2*dima + kab;
      jk1 = j*dima + k1ab;
      j1k1 = j1*dima + k1ab;
      j2k1 = j2*dima + k1ab;
      jk2 = j*dima + k2ab;
      j1k2 = j1*dima + k2ab;
      j2k2 = j2*dima + k2ab;
      for (i = 0; i < dima; i++){
        ijk=i+jk;
        tmp = data[ijk];
        if (tmp>pThreshold){
          i1 = (i + 1) % dima;
          i2 = (i + dima1) % dima;
          if (tmp >= data[i1+jk] && tmp >= data[i2+jk]){
            if (tmp >= data[i+j1k] && tmp >= data[i+j2k]){
              if (tmp >= data[i+jk1] && tmp >= data[i+jk2]){
                if (tmp > data[i1+j1k] && tmp > data[i2+j1k] && tmp > data[i1+j2k] && tmp > data[i2+j2k]){//xy
                  if (tmp > data[i1+jk1] && tmp > data[i2+jk1] && tmp > data[i1+jk2] && tmp > data[i2+jk2]){//xz
                    if (tmp > data[i+j1k1] && tmp > data[i+j2k1] && tmp > data[i+j1k2] && tmp > data[i+j2k2]){//yz
                      mList[q] = ijk;
                      wList[q] = tmp;
                      q++;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  int nMax = q;
  if (nMax > 100000)
    nMax = 100000;
  //----sort-----------------------------------
  Item* peaks = new Item[nMax];
  for (i = 0; i<nMax; i++){
    peaks[i].idx = mList[i];
    peaks[i].item = wList[i];
  }
  std::sort(peaks, peaks + nMax);
  delete[] peaks;
  return q;
}

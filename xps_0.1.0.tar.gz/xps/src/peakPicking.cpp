//=========================peakPicking.cpp======================================
//-----------------  Copyright (C) 2016 John Feng  -----------------------------
//
//   This file is a part of the package xps. Density modification.

//   The xps package is free software: you can redistribute it and/or modify
//   it under the terms of the GNU General Public License as published by
//   the Free Software Foundation, either version 2 of the License, or
//   any later version.
//
//   The xps package is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty
//   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//------------------------------------------------------------------------------

#include <numeric>
#include <algorithm>
#include <Rcpp.h>

using namespace Rcpp;

void siftDown(NumericVector data, IntegerVector list, int start, int end)
{
  int root = start;
  int child, itmp;
  float tmp;
  while ((root * 2 + 1) <= end)
  {
    child = root * 2 + 1;
    if (child < end && data[child] < data[child + 1])
    {
      child += 1;
    }
    if (data[root] < data[child])
    {
      tmp = data[root];
      data[root] = data[child];
      data[child] = tmp;
      itmp = list[root];
      list[root] = list[child];
      list[child] = itmp;
      root = child;
    }
    else
      break;
  }
}

void siftUp(NumericVector data, IntegerVector list, int start, int end)
{
  int root = start;
  int child, itmp;
  double tmp;
  while ((root * 2 + 1) <= end)
  {
    child = root * 2 + 1;
    if (child < end && data[child] > data[child + 1])
    {
      child += 1;
    }
    if (data[root] > data[child])
    {
      tmp = data[root];
      data[root] = data[child];
      data[child] = tmp;
      itmp = list[root];
      list[root] = list[child];
      list[child] = itmp;
      root = child;
    }
    else
      break;
  }
}

// [[Rcpp::export]]
void heapsort(NumericVector data, IntegerVector list, int n)
{   //high to low
  int left = n >> 1;
  int right = n - 1;
  int itmp;
  double tmp;
  while (left >= 0)
  {
    siftUp(data, list, left, right);
    left -= 1;
  }
  while (right > 0)
  {
    tmp = data[right];
    data[right] = data[0];
    data[0] = tmp;
    itmp = list[right];
    list[right] = list[0];
    list[0] = itmp;
    right -= 1;
    siftUp(data, list, 0, right);
  }
}

// [[Rcpp::export]]
NumericVector peakPicking(int nPeaks, int mDF, double pThreshold, int dima, int dimb, int dimc, NumericVector rt, NumericVector data, NumericVector data0)
{ //Pick the top nPeaks, each as a sphere of 2 pixels radius, return the modified density data1
  int i, j, k, q, i1, j1, k1, i2, j2, k2, dima1 = dima - 1, dimb1 = dimb - 1, dimc1 = dimc - 1, nab = dima*dimb, nump=dimc*nab;
  int m, m1, mi, mj, mk, kab, k1ab, k2ab, jk, j1k, j2k, jk1, j1k1, j2k1, jk2, j1k2, j2k2, ijk;
  IntegerVector mList (nump/16);//for sorting struct
  NumericVector wList (nump/16);
  NumericVector rtn(2);
  double tmp, x=1.0/dima, y=1.0/dimb, z=1.0/dimc;

  //----find---------------------------------------------------------------------------
  q = 0;
  for (k = 0; k < dimc; k++){
    k1 = (k + 1) % dimc;
    k2 = (k + dimc1) % dimc;
    kab = k*nab;
    k1ab = k1*nab;
    k2ab = k2*nab;
    for (j = 0; j < dimb; j++){
      j1 = (j + 1) % dimb;
      j2 = (j + dimb1) % dimb;
      jk = j*dima + kab;
      j1k = j1*dima + kab;
      j2k = j2*dima + kab;
      jk1 = j*dima + k1ab;
      j1k1 = j1*dima + k1ab;
      j2k1 = j2*dima + k1ab;
      jk2 = j*dima + k2ab;
      j1k2 = j1*dima + k2ab;
      j2k2 = j2*dima + k2ab;
      for (i = 0; i < dima; i++){
        ijk = i+jk;
        tmp = data[ijk];
        if (tmp>pThreshold){
          i1 = (i + 1) % dima;
          i2 = (i + dima1) % dima;
          if (tmp >= data[i1+jk] && tmp >= data[i2+jk]){
            if (tmp >= data[i+j1k] && tmp >= data[i+j2k]){
              if (tmp >= data[i+jk1] && tmp >= data[i+jk2]){
                if (tmp > data[i1+j1k] && tmp > data[i2+j1k] && tmp > data[i1+j2k] && tmp > data[i2+j2k]){//xy
                  if (tmp > data[i1+jk1] && tmp > data[i2+jk1] && tmp > data[i1+jk2] && tmp > data[i2+jk2]){//xz
                    if (tmp > data[i+j1k1] && tmp > data[i+j2k1] && tmp > data[i+j1k2] && tmp > data[i+j2k2]){//yz
                      mList[q] = ijk;
                      wList[q] = tmp;
                      q++;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  int nMax = q;
  if (nMax > 100000)
    nMax = 100000;
  //----sort---------------------------------------------------------------------------
  heapsort(wList, mList, nMax);
  //----pick---------------------------------------------------------------------------
  if(nMax<nPeaks)
    nPeaks = nMax;
  double tmpd = 0.0, dx, dy, dz, dist;
  if(mDF==0 && wList[0]>2*wList[1])
    mDF = 1;
  for (m = mDF; m < nPeaks; m++){
    m1 = mList[m];
    mk = m1 / nab;	mj = (m1%nab) / dima;	mi = (m1%nab) % dima;
    if (m>1)tmpd += wList[m];
    for (k = -2; k <= 2; k++){
      dz = k*z;
      k1 = k + mk; k1 %= dimc; if (k1 < 0)k1 += dimc;
      k2 = k1*nab;
      for (j = -2; j <= 2; j++){
        dy = j*y;
        j1 = j + mj; j1 %= dimb; if (j1 < 0)j1 += dimb;
        j2 = j1*dima + k2;
        for (i = -2; i <= 2; i++){
          dx = i*x;
          i1 = i + mi; i1 %= dima; if (i1<0)i1 += dima;
          i2 = i1 +j2;
          dist = dx*dx*rt[0] + dy*dy*rt[1] + dz*dz*rt[2] + 2.0*dx*dy*rt[3] + 2.0*dx*dz*rt[4] + 2.0*dy*dz*rt[5];
          if (dist<2.0 && data[i2]>0.0f)
            data0[i2] = data[i2];
        }
      }
    }
  }
  rtn[0] = tmpd/nPeaks;
  rtn[1] = nMax;
  return rtn;
}

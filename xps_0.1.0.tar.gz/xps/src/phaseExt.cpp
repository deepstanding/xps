//Reciprocal space modification and model evaluation
#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
NumericVector phaseExt(NumericVector real, NumericVector imag, NumericVector SF, LogicalVector wdw, NumericVector sums) {
  int m, numP = real.size();
  double tr, ti, scale, modu, tmp, dNumG, sumDF=0.0, sumFc = 0.0, sumFc2=0.0, sumFFc=0.0;

  for (m = 0; m < numP; m++){ //(real,imag) are FFTed from Eg2
    if (wdw[m]){
      dNumG += 1.0;
      sumFc2 += sqrt(real[m]*real[m]+imag[m]*imag[m]);
    }
  }
  dNumG = 1.0/dNumG;
  scale = sums[1] / sumFc2;
  for (m = 0; m < numP; m++){
    if (wdw[m]){
      real[m] *= scale;
      imag[m] *= scale;
      modu     = sqrt(real[m]*real[m]+imag[m]*imag[m]);
      tmp      = sqrt(modu);    //Ec
      sumDF   += fabs(tmp - sqrt(SF[m]));
      sumFc   += tmp;
      sumFc2  += modu;
      sumFFc  += tmp*sqrt(SF[m]);
    }
  }
  double c1 = sumFc2 - sumFc*sumFc*dNumG;
  NumericVector pars(2);
  pars[0] = (sumFFc - sums[0]*sumFc*dNumG) / sqrt(sums[2]*c1);
  pars[1] = sumDF / sums[0];
  for (m = 1; m < numP; m++){
    if (wdw[m]){
      tr = real[m];
      ti = imag[m];
      modu = sqrt(tr*tr + ti*ti);
      tmp = (2.0 * SF[m] - modu) / modu;
      real[m] *= tmp;
      imag[m] *= tmp;
    }
    else{
      real[m] = 0.0;
      imag[m] = 0.0;
    }
  }
  return pars;
}

#include <Rcpp.h>
using namespace Rcpp;

void swap(NumericVector data, int dimX, int dimY, int dimZ)
{
  float t0, t1, t2, t3, t4, t5, t6, t7;
  int i, j, k, m0, m1, m2, m3, m4, m5, m6, m7, h1 = dimX/2, nxy = dimX * dimY, numP=dimZ*nxy;
  int h2 = nxy/2, h3 = numP/2, h4 = h1 + h2, h5 = h1 + h3, h6 = h2 + h3, h7 = h1 + h2 + h3;
  for (k = 0; k < dimZ/2; k++)
  {
    for (j = 0; j < dimY/2; j++)
    {
      for (i = 0; i < h1; i++)
      {
        m0 = k * nxy + j * dimX + i;
        m1 = m0 + h1;
        m2 = m0 + h2;
        m3 = m0 + h3;
        m4 = m0 + h4;
        m5 = m0 + h5;
        m6 = m0 + h6;
        m7 = m0 + h7;
        t0 = data[m0];
        t1 = data[m1];
        t2 = data[m2];
        t3 = data[m3];
        t4 = data[m4];
        t5 = data[m5];
        t6 = data[m6];
        t7 = data[m7];
        data[m7] = t0;
        data[m6] = t1;
        data[m5] = t2;
        data[m4] = t3;
        data[m3] = t4;
        data[m2] = t5;
        data[m1] = t6;
        data[m0] = t7;
      }
    }
  }
}

void swap(LogicalVector data, int dimX, int dimY, int dimZ)
{
  float t0, t1, t2, t3, t4, t5, t6, t7;
  int i, j, k, m0, m1, m2, m3, m4, m5, m6, m7, h1 = dimX/2, nxy = dimX * dimY, numP=dimZ*nxy;
  int h2 = nxy/2, h3 = numP/2, h4 = h1 + h2, h5 = h1 + h3, h6 = h2 + h3, h7 = h1 + h2 + h3;
  for (k = 0; k < dimZ/2; k++)
  {
    for (j = 0; j < dimY/2; j++)
    {
      for (i = 0; i < h1; i++)
      {
        m0 = k * nxy + j * dimX + i;
        m1 = m0 + h1;
        m2 = m0 + h2;
        m3 = m0 + h3;
        m4 = m0 + h4;
        m5 = m0 + h5;
        m6 = m0 + h6;
        m7 = m0 + h7;
        t0 = data[m0];
        t1 = data[m1];
        t2 = data[m2];
        t3 = data[m3];
        t4 = data[m4];
        t5 = data[m5];
        t6 = data[m6];
        t7 = data[m7];
        data[m7] = t0;
        data[m6] = t1;
        data[m5] = t2;
        data[m4] = t3;
        data[m3] = t4;
        data[m2] = t5;
        data[m1] = t6;
        data[m0] = t7;
      }
    }
  }
}

// [[Rcpp::export]]
void normalizeF2(int numG0, IntegerVector Hg, IntegerVector Kg, IntegerVector Lg, NumericVector Glen, NumericVector F2, int numOP,
                 IntegerMatrix op, NumericVector gt, int dimX, int dimY, int dimZ, NumericVector Fg, NumericVector SF, LogicalVector wdw){

  int i, j, k, i1, j1, k1, k2, j2, i2, k3, j3, i3, m, m1, n, v, hx = dimX/2, hy = dimY/2, hz = dimZ/2, nxy = dimX * dimY, dim=512;
  NumericVector fr0(dim), rr0(dim);
  IntegerVector nr0(dim);
  double maxlen=0.0;
  int gMax = 1;
  for(m=0;m<numG0;m++){
    if(abs(Hg[m])>gMax)
      gMax = abs(Hg[m]);
    if(abs(Kg[m])>gMax)
      gMax = abs(Kg[m]);
    if(abs(Lg[m])>gMax)
      gMax = abs(Lg[m]);
    if(Glen[m]>maxlen)
      maxlen = Glen[m];
  }
  maxlen*=1.0001;

  //1.Divide the reciprocal space into shells of approxiamtely equal volume (same anglular distribution)
  //--expand F2 by full symmetry	&
  //find equivalent reflections
  double modu;
  for(v=0; v<numG0; v++)
  {	//origin at 000
		if(F2[v]>0.0){
			modu = sqrt(F2[v]);
			i = Hg[v]+hx;
			j = Kg[v]+hy;
			k = Lg[v]+hz;
			m = k*nxy+j*dimX+i;
			if(wdw[m]){//redundant data
			}
			else{
				SF[m] = F2[v];
				wdw[m]  = true;
				Fg[m]   = modu;
			}
			for (n = 1; n < numOP; n++)
			{	//op matrix in reciprocal is the transpose of that in direct space
				i = Hg[v] * op(n,0) + Kg[v] * op(n,3) + Lg[v] * op(n,6);
				j = Hg[v] * op(n,1) + Kg[v] * op(n,4) + Lg[v] * op(n,7);
				k = Hg[v] * op(n,2) + Kg[v] * op(n,5) + Lg[v] * op(n,8);
				i += hx;  j+=hy;  k+=hz;
				m = k*nxy+j*dimX+i;
				if(wdw[m]){//redundant data: should not happen
				}
				else{
					SF[m] = F2[v];
					wdw[m]  = true;
					Fg[m]   = modu;
				}
			}
		}
	}

	//===Assign DF if Freidel pair exist: no modification to the wdw!!! Or to Fg
	for(k=1; k<dimZ; k++){
		k1 = dimZ-k;	//range 1--dimZ-1
		k2=k*nxy;	k3=k1*nxy;
		for(j=1; j<dimY; j++){
			j1 = dimY-j;
			j2 = k2+j*dimX;	j3=k3+j1*dimX;
			for(i=1; i<dimX; i++){
				i1 = dimX-i;
				i2 = i+j2;
				i3 = i1+j3;
				if(wdw[i2] && !wdw[i3]){
					//bMerged = true;
					wdw[i3] =true;
					Fg[i3]=Fg[i2];
					SF[i3] = SF[i2];
				}
				else if(wdw[i3] && !wdw[i2]){
					//bMerged = true;
					wdw[i2] =true;
					Fg[i2]=Fg[i3];
					SF[i2] = SF[i3];
				}
			}
		}
	}
	//------------------------------------
	int numG = 0;
	for(k=0; k<dimZ; k++){
		k1 = k*nxy;
		for(j=0; j<dimY; j++){
			j1 = k1+j*dimX;
			for(i=0; i<dimX; i++){
				i1 = i+j1;
				if(SF[i1]>0.0){
					numG++;
					wdw[i1] = true;
				}
				else{
					wdw[i1] = false;
				}
			}
		}
	}

  int nS0 = numG/200;//?
	if(nS0>gMax)
		nS0 = gMax;

	double tmpr;
	for(v=0; v<nS0+1; v++){
		tmpr = (double)v/(double)nS0;
		rr0[v] = maxlen*pow(tmpr, 1.0/1.5);
	}

    for (i = 0; i < dim; i++)
    {
        fr0[i] = 0.0;
        nr0[i] = 0;
    }

    int H, K, L, H2, K2, L2;
	double gLen, tmp;//in 1/A2
	for(k=0; k<dimZ; k++){
	  L = k-hz;	L2 = L*L;
	  k1 = k*nxy;
	  for(j=0; j<dimY; j++){
	    K = j-hy;	K2 = K*K;
	    j1 = k1+j*dimX;
	    for(i=0; i<dimX; i++){
	      if(SF[i+j1]!=0.0)
	      {
	        H = i-hx;	H2 = H*H;
	        gLen = (H2 * gt[0] + K2 * gt[1] + L2 * gt[2] + H * K * gt[3] + H*L * gt[4] + K*L * gt[5]);
	        v = (int)(nS0*pow(gLen/maxlen, 1.5));
	        nr0[v]++;
	        fr0[v]+=SF[i+j1];
	      }
	    }}}

	//normalize F2
	for(v=0; v<nS0; v++){
	  if(nr0[v]>0.0)
	    fr0[v] /=nr0[v];
	  else
	    fr0[v] = 1.0;
	}

	for(k=0; k<dimZ; k++){
	  L = k-hz;		L2 = L*L;
	  k1=k*nxy;
	  for(j=0; j<dimY; j++){
	    K=j-hy;		K2=K*K;
	    j1=k1+j*dimX;
	    for(i=0; i<dimX; i++){
	      m=k*nxy+j*dimX+i;
	      if(SF[i+j1]!=0.0){
	        H=i-hx;		H2 = H*H;
	        gLen = (H2 * gt[0] + K2 * gt[1] + L2 * gt[2] + H * K * gt[3] + H * L * gt[4] + K*L * gt[5]);
	        v = (int)(nS0*pow(gLen/maxlen, 1.5));
	        SF[m]= SF[i+j1]/fr0[v];
	      }
	    }}}

  swap(SF, dimX, dimY, dimZ);
	swap(Fg, dimX, dimY, dimZ);
	swap(wdw, dimX, dimY, dimZ);
	wdw[0]=false;
  SF[0] = 0.0;
}

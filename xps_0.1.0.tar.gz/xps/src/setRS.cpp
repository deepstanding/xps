#include <Rcpp.h>
using namespace Rcpp;

// [[Rcpp::export]]
void setRS(NumericVector real, NumericVector f2, LogicalVector wdw){
  int n=f2.size();
  for(int i=0;i<n;i++){
    if(wdw[i])
      real[i] = f2[i]-1.0;
    else
      real[i] = 0.0;
  }
}

